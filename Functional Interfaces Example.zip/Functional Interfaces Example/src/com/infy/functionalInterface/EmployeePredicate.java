package com.infy.functionalInterface;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class EmployeePredicate  {
	
	public static List<Employee> filterEmployee(List<Employee> emp, Predicate<Employee> predicate) {
		return emp.stream().filter(predicate).collect(Collectors.toList());
	}
	
}
