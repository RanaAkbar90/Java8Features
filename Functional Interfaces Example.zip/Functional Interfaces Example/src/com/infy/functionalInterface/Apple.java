package com.infy.functionalInterface;

public class Apple {

	private Integer fruiteId;
	private String color;
	private Double weight;
	
	public Apple() {
		// TODO Auto-generated constructor stub
	}

	public Apple(Integer fruiteId,String color, Double weight) {
		this.fruiteId=fruiteId;
		this.color = color;
		this.weight = weight;
	}

	public Integer getFruiteId() {
		return fruiteId;
	}

	public void setFruiteId(Integer fruiteId) {
		this.fruiteId = fruiteId;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	@Override
	public String toString() {
		return "Apple [fruiteId=" + fruiteId + ", color=" + color + ", weight=" + weight + "]";
	}
}
