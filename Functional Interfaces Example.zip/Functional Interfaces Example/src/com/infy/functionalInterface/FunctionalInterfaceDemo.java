package com.infy.functionalInterface;

import java.awt.Checkbox;
import java.io.ObjectInputStream.GetField;
import java.util.Arrays;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.BiPredicate;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

public class FunctionalInterfaceDemo {

	public static void main(String[] args) {
		List<Employee> empList = Arrays.asList(new Employee(123, "Abc", "Java"), new Employee(698, "Pqr", "SAP"),
				new Employee(875, "Xyz", "Python"));
		List<Apple> appleList = Arrays.asList(new Apple(101, "Red", 964.3), new Apple(102, "Brown", 968.6),
				new Apple(103, "Green", 652.8));

		// Predicate
		System.out.println("================Examples of Predicate===============");
		EmployeePredicate.filterEmployee(empList, emp -> {
			return emp.getId() >= 150;
		}).forEach(System.out::print);

		System.out.println();

		EmployeePredicate.filterEmployee(empList, emp -> {
			return emp.getDept().equalsIgnoreCase("java");
		}).forEach(System.out::println);
		System.out.println();

		// Consumer
		System.out.println("================Examples of Consumer===============");
		Consumer<String> show = c -> System.out.println(c);
		show.accept("I am from Supplier");

		Consumer<List<Employee>> modify = list -> {
			list.stream().forEach(emp -> {
				System.out.println(emp);
			});
		};
		modify.accept(empList);
		System.out.println();

		// Function
		System.out.println("================Examples of Function===============");
		Function<Integer, Double> partition = p -> p / 2.0;
		System.out.println(partition.apply(9685));

		Function<Employee, Integer> getId = id -> id.getId();
		System.out.println("The Id Of employee " + empList.get(2).getName() + " is:::::" + getId.apply(empList.get(2)));
		System.out.println();
;
		// Supplier
		System.out.println("================Examples of Supplier===============");
		Supplier<String> sup = () -> empList.get(2).getName();
		System.out.println(sup.get());

		Supplier<String> app = () -> appleList.toString();
		System.out.println(app.get());
		System.out.println();

		// UnaryOperator
		System.out.println("================Examples of UnaryOperator===============");
		UnaryOperator<Double> weight=t->t*2;
		System.out.println(weight.apply(appleList.get(1).getWeight()));
		
		UnaryOperator<String> surname=t->t.concat("Laxman");
		System.out.println(surname.apply(empList.get(1).getName()));
		System.out.println();
		
		// BinaryOperator
		System.out.println("================Examples of BinaryOperator===============");
		BinaryOperator<Integer> biOperator=BinaryOperator.maxBy((a,b)->(a>b)?1:((a==b)?0:-1));
		System.out.println(biOperator.apply(858,698));
		
		BinaryOperator<Integer> biOperatorMin=BinaryOperator.minBy((a,b)->(a>b)?1:((a==b)?0:-1));
		System.out.println(biOperatorMin.apply(858,698));
		System.out.println();
		
		// BiPredicate
		System.out.println("================Examples of BiPredicate===============");
		BiPredicate<String,String> strCheck=(s1,s2)->s1.equalsIgnoreCase(s2);
		System.out.println(strCheck.test(empList.get(2).getName(),appleList.get(2).getColor()));
		
		BiPredicate<Integer,Integer> intCheck=(s1,s2)->s1==s2;
		System.out.println(intCheck.test(empList.get(1).getId(),appleList.get(1).getFruiteId()));
		System.out.println();
		
		// BiConsumer
		System.out.println("================Examples of BiConsumer===============");
		BiConsumer<List<Employee>, List<Apple>> compare = (emp, apple) -> {
			emp.stream().forEach(e -> System.out.print(e + ""));
			System.out.println();
			apple.stream().forEach(a -> System.out.print(a + ""));
		};

		compare.accept(empList, appleList);
		System.out.println();

		// BiFunction
		System.out.println("================Examples of BiFunction===============");
		BiFunction<String, String, Integer> findLength = (s1, s2) -> {
			return (s1 + s2).length();
		};
		System.out.println(findLength.apply("Functional", "Interface"));

		BiFunction<List<Employee>, List<Apple>, Boolean> check = (empl1, apple1) -> {
			return empl1.size() == apple1.size();
		};
		System.out.println(check.apply(empList, appleList));

	}

}
