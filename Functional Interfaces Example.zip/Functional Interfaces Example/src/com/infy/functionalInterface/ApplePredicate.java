package com.infy.functionalInterface;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ApplePredicate {

	public static List<Apple> filterApples(List<Apple> apples, Predicate<Apple> predicate){
		return apples.stream().filter(predicate).collect(Collectors.toList());
	}
}
