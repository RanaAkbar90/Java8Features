package com.infy.exercise2;

public class DemoThreadMine {

	public static void main(String[] args) {

		Runnable runInstance=()->{
			System.out.println("This is run method");
		};
		Thread threadInstance=new Thread(runInstance) ;
		threadInstance.start();
	}

}
