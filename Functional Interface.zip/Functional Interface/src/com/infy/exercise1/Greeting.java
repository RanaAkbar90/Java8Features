package com.infy.exercise1;

@FunctionalInterface
public interface Greeting {

	void greet();
}
