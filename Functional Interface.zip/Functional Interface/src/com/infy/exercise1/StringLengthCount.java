package com.infy.exercise1;

public interface StringLengthCount {

	int stringLengthCountFunc(String s);
}
