package com.infy.exercise1;

interface Division {

	float div(int c,int d);
}
