package com.infy.exercise1;

public interface Addition {
	int add(int a, int b);

}
