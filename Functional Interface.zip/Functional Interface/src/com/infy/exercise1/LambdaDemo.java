package com.infy.exercise1;

public class LambdaDemo {

	public static void main(String[] args) {
		//Using Greeting interface
		Greeting greetReference=()->System.out.println("Hello Dear");
		greetReference.greet();

		//Using Addition interface
		Addition addReference=(a,b)-> a+b;
		addReference.add(96, 65);
		
		//Using Division interface
		Division divReference=(c,d)->{
			float result=0.0F;
			try {
				result=c/d;
				System.out.println("Division is"+result);
			}
			catch (ArithmeticException e) {
				e.printStackTrace();
			}
			return result;

		};
		divReference.div(10,3);

		// Using StringLengthCount interface
		StringLengthCount strCount = (s) -> {
			int count = 0;
			count=s.length();
			System.out.println("The length of String is"+count);
			return count;
		};
		strCount.stringLengthCountFunc("LambdaExpression");

		// Using DoubleNumberFunction Interface

		DoubleNumber doubleNumRef = (e, f) -> {
			double result = e * f;
			System.out.println("Double" + result);
			return result;
		};
		doubleNumRef.doubleNumberFunction(98.5d, 2.5d);
	}

}
