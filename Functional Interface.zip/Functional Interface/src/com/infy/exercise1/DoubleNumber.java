package com.infy.exercise1;

public interface DoubleNumber {

	double doubleNumberFunction(double e, double f);
}
