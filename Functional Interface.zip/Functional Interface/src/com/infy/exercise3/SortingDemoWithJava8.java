package com.infy.exercise3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class SortingDemoWithJava8 {

	public static void main(String[] args) {
		List<CountryOrder> countryList = new ArrayList<CountryOrder>();

		countryList.add(new CountryOrder("India", 98));
		countryList.add(new CountryOrder("China", 59));
		countryList.add(new CountryOrder("Australia", 69));
		countryList.add(new CountryOrder("Dubai", 68));
		countryList.add(new CountryOrder("Bangladesh", 86));
		countryList.add(new CountryOrder("England", 85));
		System.out.println("Before sorting::::::::::" + countryList);

		// Sorting with Anonymous inner class
		countryList.sort(new Comparator<CountryOrder>() {

			@Override
			public int compare(CountryOrder o1, CountryOrder o2) {
				return o1.getCountry().compareTo(o2.getCountry());

			}

		});
		System.out.println("After sorting:::::::::::" + countryList);

		// Sorting with Lambda expression
		Comparator<CountryOrder> cmpr = (c1, c2) -> {
			return c1.getCountry().compareTo(c2.getCountry());
		};
		countryList.sort(cmpr);
		System.out.println("After sorting:::::::::::" + countryList);

	}
}
