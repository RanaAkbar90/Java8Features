package com.infy.exercise3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class SortingDemo implements Comparator<CountryOrder> {

	@Override
	public int compare(CountryOrder o1, CountryOrder o2) {
		return o1.getCountry().compareTo(o2.getCountry());
	}

}
