package com.infy.exercise3;

public class CountryOrder {

	private String country;
	private int order;

	public CountryOrder() {
		// TODO Auto-generated constructor stub
	}

	public CountryOrder(String country, int order) {
		this.country = country;
		this.order = order;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	@Override
	public String toString() {
		return "CountryOrder [country=" + country + ", order=" + order + "]";
	}

}
