package com.infy.exercise3;

import java.util.ArrayList;
import java.util.List;

public class SortDemoWithJava7 {

	public static void main(String[] args) {
		List<CountryOrder> countryList = new ArrayList<CountryOrder>();

		countryList.add(new CountryOrder("India", 98));
		countryList.add(new CountryOrder("China", 59));
		countryList.add(new CountryOrder("Australia", 69));
		countryList.add(new CountryOrder("Dubai", 68));
		countryList.add(new CountryOrder("Bangladesh", 86));
		countryList.add(new CountryOrder("England", 85));
		System.out.println("Before sorting::::::::::"+countryList);

		countryList.sort(new SortingDemo());
		System.out.println("After sorting:::::::::::"+countryList);
	}
}
