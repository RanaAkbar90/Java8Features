package com.infy.exercise4;

@FunctionalInterface
public interface StringLength {

	int LengthOfString(String s);
}
