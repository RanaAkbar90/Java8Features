package com.infy.exercise4;

public class StringLengthDemo {

	public static void main(String[] args) {

		StringLength strLength=(s)-> {
			int result=0;
			result=s.length();
			System.out.println("Length of String is"+result);
			return result;
		};
		strLength.LengthOfString("MyLambdaExpression");
	}

}
